export default {
  templateRepoId: 'sanity-io/sanity-template-gatsby-blog'
}
